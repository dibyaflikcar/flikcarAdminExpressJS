/* eslint-disable linebreak-style */
module.exports = {
    test: 'test',
    admin: 'admins',
    bodytype: 'bodyTypes',
    city: 'cities',
    color: 'colors',
    fueltype: 'fuelTypes',
    makeAndModel: 'brand_model_variants',
    seat: 'seats',
    ownerType: 'ownerTypes',
    AuctionVehicle: 'auction_vehicles',
    auction: 'auctions',
  };
